<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentUserController extends Controller
{
    //
}
