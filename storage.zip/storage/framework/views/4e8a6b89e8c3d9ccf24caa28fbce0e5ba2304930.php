<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>