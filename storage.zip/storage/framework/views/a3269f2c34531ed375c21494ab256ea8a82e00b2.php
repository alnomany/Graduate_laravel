<table class="table">
    <thead>
        <tr>
            <th>Actions</th>

            <th>Student</th>
            <th>Patient</th>
            <th>tooth number</th>
            <th>procedure</th>
            <th>FM1</th>
            <th>FM2</th>
            <th>FM3</th>
            <th>FM4</th>
            <th>FM5</th>
            <th>FM6</th>
            <th>avg</th>


            <th>Note</th>



        </tr>
    </thead>
    <div id="body-html"></div>
    <tbody >
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <div class="dropdown">
                    <a href="<?php echo e(route('fixform.edit', collect($value)->first() )); ?>">
                        edit
                        <i class="livicon" data-name="edit" data-size="18" data-loop="true" data-c="#428BCA" data-hc="#428BCA" title="edit incident"></i>
                    </a>


                        

                    </div>
            </td>
            <td>

                <span class="font-weight-bold"><?php echo e($value->student_name); ?><br><br> <?php echo e($value->student_number); ?></span>
            </td>
            <td><?php echo e($value->p_name); ?><br><br> <?php echo e($value->p_rn); ?></td>
            <td><?php echo e($value->tooth_number); ?></td>
            <td><?php echo e($value->rest_type); ?></td>


            <td><?php echo e($value->fm1); ?><br><br> <?php echo e($value->fm1_sig); ?></td>
            <td><?php echo e($value->fm2); ?><br><br> <?php echo e($value->fm2_sig); ?></td>
            <td><?php echo e($value->fm3); ?> <br><br> <?php echo e($value->fm3_sig); ?></td>
            <td><?php echo e($value->fm4); ?><br><br> <?php echo e($value->fm4_sig); ?></td>
            <td><?php echo e($value->fm5); ?><br><br> <?php echo e($value->fm5_sig); ?></td>
            <td><?php echo e($value->fm6); ?><br><br> <?php echo e($value->fm6_sig); ?></td>
            <td><?php echo e($value->avg); ?><br></td>
            <td><?php echo e($value->note); ?></td>





        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\resources\views/fixed_form/fill_data.blade.php ENDPATH**/ ?>