<table>
    <thead>
    <tr>
        <th>StuNum</th>
        <th>StuName</th>
        <th>PRN</th>
        <th>Patient Name</th>
        <th>preparation plan mark</th>

        <th>Tooth </th>
        <th>Restoration type</th>

        <th>Examination and Tx Planning</th>
        <th>Sign</th>
        <th>Provisional</th>
        <th>Sign</th>

        <th>Final impression/ resin pattern</th>
        <th>Sign</th>
        <th>Prefab post cementation core build-up</th>
        <th>Sign</th>
        <th>Try-in</th>
        <th>Sign</th>
        <th>Cementation</th>
        <th>Sign</th>
        <th>Average</th>





    </tr>

    </thead>
    <tbody>
    <?php $__currentLoopData = $fixform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>

            <td><?php echo e($data->student_number); ?></td>
            <td><?php echo e($data->student_name); ?></td>
            <td><?php echo e($data->p_rn); ?></td>
            <td><?php echo e($data->p_name); ?></td>
            <td><?php echo e($data->p_rn); ?></td>
            <td><?php echo e($data->p_name); ?></td>
            <td><?php echo e($data->fm0); ?></td>

            <td><?php echo e($data->tooth_number); ?></td>
            <td><?php echo e($data->rest_type); ?></td>

            <td><?php echo e($data->fm1); ?></td>
            <td><?php echo e($data->fm1_sig); ?></td>
            <td><?php echo e($data->fm2); ?></td>
            <td><?php echo e($data->fm2_sig); ?></td>

            <td>
                <?php if(empty($data->fm3)): ?>
                N.A.
             <?php endif; ?>
             <?php echo e($data->fm3); ?>

            </td>
            <td>
                <?php if(empty($data->fm3_sig)): ?>
                N.A.
             <?php endif; ?>
                <?php echo e($data->fm3_sig); ?>

            </td>
            <td>
             <?php if(empty($data->fm4)): ?>
                N.A.
             <?php endif; ?>
             <?php echo e($data->fm4); ?>

            </td>
            <td>
                <?php if(empty($data->fm4_sig)): ?>
                N.A.
             <?php endif; ?>
                <?php echo e($data->fm4_sig); ?>

            </td>


            <td>
                <?php if(empty($data->fm5)): ?>
                   N.A.
                <?php endif; ?>
                <?php echo e($data->fm5); ?>

            </td>
            <td>
                <?php if(empty($data->fm5_sig)): ?>
                N.A.
                <?php endif; ?>
                <?php echo e($data->fm5_sig); ?>

            </td>
            <td>
                <?php if(empty($data->fm6)): ?>
                N.A.
                <?php endif; ?>
                <?php echo e($data->fm6); ?>

            </td>
            <td>
                <?php if(empty($data->fm6_sig)): ?>
                N.A.
                <?php endif; ?>
                <?php echo e($data->fm6_sig); ?>

            </td>
            <td><?php echo e($data->avg); ?></td>





        </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table>
    <thead>
        <tr>
            <th>average</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo e($avg_total=DB::table('fix_forms')
                ->avg('avg')); ?></td>
        </tr>
    </tbody>

</table>


<?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\resources\views/exports/fixform.blade.php ENDPATH**/ ?>