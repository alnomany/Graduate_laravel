<?php $__env->startSection('content'); ?>
<div class="container">
    
        <section id="dashboard-ecommerce">
            <div class="row match-height">
                <!-- Medal Card -->
                <div class="col-xl-8 col-md-8 col-8">
                    <div class="card card-congratulation-medal">
                        <div class="card-body">
                            <h5>welcome 🎉                                     <?php echo e(Auth::user()->name); ?>

                            </h5>
                            <p class="card-text font-small-3">chose one</p>
                            <a href="<?php echo e(route('create')); ?>">
                            <button type="button" class="btn btn-primary">Fixed</button>
                            </a>
                            <img src="../../../app-assets/images/illustration/badge.sv" class="congratulation-medal" alt="" />

                            <button type="button" class="btn btn-primary">Removable</button>
                            <img src="../../../app-assets/images/illustration/badge.sv" class="congratulation-medal" alt="" />
                            <a href="<?php echo e(route('fill')); ?>">
                            <button type="button" class="btn btn-primary">Fill Form</button>
                            </a>
                            <img src="../../../app-assets/images/illustration/badge.sv" class="congratulation-medal" alt="" />
                            <img src="../../../app-assets/images/illustration/badge.sv" class="congratulation-medal" alt="" />
                            <a href="<?php echo e(route('fill.export')); ?>">

                            <button type="button" class="btn btn-primary">Report</button>
                            <img src="../../../app-assets/images/illustration/badge.sv" class="congratulation-medal" alt="" />
                            </a>
                        </div>
                    </div>
                </div>
                <!--/ Medal Card -->


            </div>
        </section>
        
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\resources\views/home.blade.php ENDPATH**/ ?>