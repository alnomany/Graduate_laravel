<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-left d-block d-md-inline-block mt-25"> &copy; 2022<a class="ml-25" href="" target="_blank"></a><span class="d-none d-sm-inline-block">جميع الحقوق محفوظة</span></span></p>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
<!-- END: Footer-->
<?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>