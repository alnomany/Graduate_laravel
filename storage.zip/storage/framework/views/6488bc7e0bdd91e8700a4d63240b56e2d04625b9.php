<?php echo e($slot); ?>

<?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>