
<div class="row">
    <div class="col-md-4 col-4">
        <div class="form-group">
            <label for="Student Number">Student Number</label>

            <select id="student-number" class="select2 form-control form-control-lg" name="student_number">
                <?php $__currentLoopData = $students_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($student->student_number); ?>"><?php echo e($student->student_number); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        </div>
    <div class="col-md-4 col-4">
        <div class="form-group">
            <label for="Student Name">Student Name</label>
            <select id="student-name" class="select2 form-control form-control-lg" name="student_name">

            </select>

        </div>
    </div>
        <div class="col-md-4 col-sm-4 col-4">
            <div class="form-group">
                <label for="PRN">Patient Number-PRN</label>
                <select id="PRN" class="select2 form-control form-control-lg" name="p_rn">

            </div>
        </div>
        <div class="col-md-6 col-6" style="">
            <div class="form-group">
                <label for="PName" >Patient Name</label>

                <input type="text" id="PName" style="display:none;" class="form-control" name="p_name" placeholder="Patient Name" />
            </div>
        </div>

        <div class="table-responsive" id="fill_data">

            <?php echo $__env->make('fixed_form.fill_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
<?php /**PATH C:\xampp7.4n\htdocs\Graduate_laravel\resources\views/fixed_form/fill_fields.blade.php ENDPATH**/ ?>