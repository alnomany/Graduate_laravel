<script>
    $(document).on("change", ".rm0", function() {
        var str = $("#sig_name").val();
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm0_date").value = current_date;
        $(".rm0_sig").val(str);
    });
    $(document).on("change", ".rm1", function() {
        var str = $("#sig_name").val();
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm1_date").value = current_date;
       // alert(date);
        $(".rm1_sig").val(str);
    });
    $(document).on("change", ".rm2", function() {
        var str = $("#sig_name").val();
        var date = new Date();

        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm2_date").value = current_date;
        $(".rm2_sig").val(str);


    });
    $(document).on("change", ".rm3", function() {
        var str = $("#sig_name").val();
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm3_date").value = current_date;
        $(".rm3_sig").val(str);
    });
    $(document).on("change", ".rm4", function() {
        var str = $("#sig_name ").val();
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm4_date").value = current_date;
        $(".rm4_sig").val(str);
    });
    $(document).on("change", ".rm5", function() {
        var str = $("#sig_name ").val();
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm5_date").value = current_date;
        $(".rm5_sig").val(str);
    });
    $(document).on("change", ".rm6", function() {
        var str = $("#sig_name ").val();
       // alert(date);
        $(".rm6_sig").val(str);
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours() + ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm6_date").value = current_date;
    });
    $(document).on("change", ".rm7", function() {
        var str = $("#sig_name").val();
        var date = new Date();
        var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
        document.getElementById("rm7_date").value = current_date;
        $(".rm7_sig").val(str);
    });
    $(document).on("change", ".rm8", function() {
        var str = $("#sig_name").val();
          $(".rm8_sig").val(str);
          var date = new Date();
          var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
          document.getElementById("rm8_date").value = current_date;
    });
    $(document).on("change", ".rm9", function() {
        var str = $("#sig_name").val();
          $(".rm9_sig").val(str);
          var date = new Date();
          var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
          document.getElementById("rm9_date").value = current_date;
    });
    $(document).on("change", ".rm10", function() {
        var str = $("#sig_name").val();
          $(".rm10_sig").val(str);
          var date = new Date();
          var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
          document.getElementById("rm10_date").value = current_date;
    });
    $(document).on("change", ".rm11", function() {
        var str = $("#sig_name").val();
          $(".rm11_sig").val(str);
          var date = new Date();
          var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
          document.getElementById("rm11_date").value = current_date;
    });
    $(document).on("change", ".rm12", function() {
        var str = $("#sig_name").val();
          $(".rm12_sig").val(str);
          var date = new Date();
          var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
          document.getElementById("rm12_date").value = current_date;
    });
    $(document).on("change", ".rm13", function() {
        var str = $("#sig_name").val();
          $(".rm13_sig").val(str);
          var date = new Date();
          var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate() + "  " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds();
          document.getElementById("rm13_date").value = current_date;
    });
</script>
